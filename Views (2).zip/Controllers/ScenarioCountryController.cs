﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ScenarioCountryController : Controller
    {
        private readonly IConfiguration _configuration;

        public ScenarioCountryController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            var countriess = GetCountriesFromDatabase();
            return View(countriess);
        }

        [HttpPost]
        public IActionResult AddCountry(Countries countries)
        {
            AddCountriesToDatabase(countries);
            var countriess = GetCountriesFromDatabase();
            return Ok(countriess);
        }

        [HttpPut]
        public IActionResult UpdateCountry(Countries countries)
        {
            UpdateCountriesToDatabase(countries);
            var countriess = GetCountriesFromDatabase();
            return Ok(countriess);
        }

        [HttpDelete]
        public IActionResult DeleteCountry(int countriesId)
        {
            DeleteCountriesToDatabase(countriesId);
            return Ok();
        }

        private List<Countries> GetCountriesFromDatabase()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            var countriess = new List<Countries>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT CountryId, CountryName, Continent, Region FROM Application.Countries", connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var countries = new Countries
                            {
                                CountryId = reader.GetInt32(0),
                                CountryName = reader.GetString(1),
                                Continent = reader.GetString(2),
                                Region = reader.GetString(3),
                            };
                            countriess.Add(countries);
                        }
                    }
                }
            }

            return countriess;
        }
        private void AddCountriesToDatabase(Countries countries)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("INSERT INTO Application.Countries (CountryId, CountryName, Continent, Region) VALUES (@CountrieId, @Name, @Continent, @Region)", connection))
                {
                    command.Parameters.AddWithValue("@CountrieId", countries.CountryId);
                    command.Parameters.AddWithValue("@Name", countries.CountryName);
                    command.Parameters.AddWithValue("@Continent", countries.Continent);
                    command.Parameters.AddWithValue("@Region", countries.Region);

                    command.ExecuteNonQuery();
                }
            }
        }

        private void UpdateCountriesToDatabase(Countries countries)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("UPDATE Application.Countries SET CountryName = @Name, Continent = @Continent, Region = @Region WHERE CountryId = @CountryId", connection))
                {
                    command.Parameters.AddWithValue("@Name", countries.CountryName);
                    command.Parameters.AddWithValue("@Continent", countries.Continent);
                    command.Parameters.AddWithValue("@Region", countries.Region);
                    command.Parameters.AddWithValue("@CountryId", countries.CountryId);

                    command.ExecuteNonQuery();
                }
            }
        }

        private void DeleteCountriesToDatabase(int countriesId)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("DELETE FROM Application.Countries WHERE CountryId = @CountryId", connection))
                {
                    command.Parameters.AddWithValue("@CountrieId", countriesId);

                    command.ExecuteNonQuery();
                }
            }
        }
    }
}

