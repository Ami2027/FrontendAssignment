﻿using Microsoft.AspNetCore.Mvc;
using System.Data.SqlClient;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ScenarioProjController : Controller
    {
        private readonly IConfiguration _configuration;

        public ScenarioProjController(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public IActionResult Index()
        {
            var projects = GetProjectsFromDatabase();
            return View(projects);
        }

        [HttpPost]
        public IActionResult AddProject(Project project)
        {
            AddProjectsToDatabase(project);
            var projects = GetProjectsFromDatabase();
            return Ok(projects);
        }

        [HttpPut]
        public IActionResult UpdateProject(Project project)
        {
            UpdateProjectsToDatabase(project);
            var projects = GetProjectsFromDatabase();
            return Ok(projects);
        }

        [HttpDelete]
        public IActionResult DeleteProject(int projectId)
        {
            DeleteProjectsToDatabase(projectId);
            return Ok();
        }

        private List<Project> GetProjectsFromDatabase()
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");
            var projects = new List<Project>();

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("SELECT ProjectId, Name, Status, Revenue FROM Projects", connection))
                {
                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var project = new Project
                            {
                                ProjectId = reader.GetInt32(0),
                                Name = reader.GetString(1),
                                Status = reader.GetString(2),
                                Revenue = reader.GetDecimal(3)
                            };
                            projects.Add(project);
                        }
                    }
                }
            }

            return projects;
        }
        private void AddProjectsToDatabase(Project project)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("INSERT INTO Projects (ProjectId, Name, Status, Revenue) VALUES (@ProjectId, @Name, @Status, @Revenue)", connection))
                {
                    command.Parameters.AddWithValue("@ProjectId", project.ProjectId);
                    command.Parameters.AddWithValue("@Name", project.Name);
                    command.Parameters.AddWithValue("@Status", project.Status);
                    command.Parameters.AddWithValue("@Revenue", project.Revenue);

                    command.ExecuteNonQuery();
                }
            }
        }

        private void UpdateProjectsToDatabase(Project project)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("UPDATE Projects SET Name = @Name, Status = @Status, Revenue = @Revenue WHERE ProjectId = @ProjectId", connection))
                {
                    command.Parameters.AddWithValue("@Name", project.Name);
                    command.Parameters.AddWithValue("@Status", project.Status);
                    command.Parameters.AddWithValue("@Revenue", project.Revenue);
                    command.Parameters.AddWithValue("@ProjectId", project.ProjectId);

                    command.ExecuteNonQuery();
                }
            }
        }

        private void DeleteProjectsToDatabase(int projectId)
        {
            string connectionString = _configuration.GetConnectionString("DefaultConnection");


            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                using (SqlCommand command = new SqlCommand("DELETE FROM Projects WHERE ProjectId = @ProjectId", connection))
                {
                    command.Parameters.AddWithValue("@ProjectId", projectId);

                    command.ExecuteNonQuery();
                }
            }
        }
    }
}

