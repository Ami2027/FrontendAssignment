﻿namespace WebApplication1.Models
{
    public class Countries
    {
        public int CountryId { get; set; }
        public string CountryName { get; set; }
        public string Continent { get; set; }
        public string Region { get; set; }
    }
}
