﻿namespace WebApplication1.Models
{
    public class Project
    {
        public int ProjectId { get; set; }
        public string Name { get; set; }
        public string Status { get; set; }
        public decimal Revenue { get; set; }
    }
}
